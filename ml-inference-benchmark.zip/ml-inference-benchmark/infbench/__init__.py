"""infbench: compare inference implementations of one MLP for speed, memory and numerical correctness."""
