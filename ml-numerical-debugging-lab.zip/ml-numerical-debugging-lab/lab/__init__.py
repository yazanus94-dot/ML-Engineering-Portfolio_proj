"""Numerical debugging lab: realistic ML bugs, each with a symptom, root cause, fix and a test that proves it."""
